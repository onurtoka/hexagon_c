#include "domain/model/TrackData.hpp"
namespace domain {
namespace model {
TrackData::TrackData() {
}
TrackData::~TrackData() {
}
}
}